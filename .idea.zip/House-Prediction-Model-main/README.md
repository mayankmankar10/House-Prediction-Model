# House-Prediction-Model
Created a web application using flask server by integrating machine learning model that predicts the home prices in bangalore depending upon the suitable attributes.
